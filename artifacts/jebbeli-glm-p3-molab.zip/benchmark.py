#!/usr/bin/env python3
"""Frozen, paired P2/P3 benchmark for GLM on Cloudflare Workers AI."""

import argparse
from contextlib import closing, contextmanager
import fcntl
import hashlib
from http.client import HTTPException
import json
import os
from pathlib import Path
import re
import signal
import socket
import sqlite3
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener

ROOT = Path(__file__).resolve().parent
DB_NAME = "p2-p3-results.sqlite3"
LOCK_NAME = ".p2-p3-benchmark.lock"
BUDGET = 24
TIMEOUT = 180
MODEL = "@cf/zai-org/glm-4.7-flash"
PARAMETERS = {
    "temperature": 0.1,
    "max_completion_tokens": 700,
    "chat_template_kwargs": {"enable_thinking": False},
}
FINISH_REASONS = {"stop", "length", "content_filter", "tool_calls", "function_call", "error"}
CONTINUE = {"OK", "PARTIAL", "EMPTY"}


class BenchmarkError(Exception):
    """Contains an operator-facing message without request details."""


@contextmanager
def deadline(seconds):
    def expired(*_):
        raise TimeoutError()

    previous_handler = signal.signal(signal.SIGALRM, expired)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


def dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_manifest():
    return dict((name, digest) for digest, name in (
        line.split() for line in (ROOT / "manifests.sha256").read_text().splitlines()
    ))


def read_credentials():
    """Read two keys without sourcing, expanding, or printing the .env file."""
    values = {}
    path = ROOT / ".env"
    if path.is_file():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            if line.lstrip().startswith("#"):
                continue
            key, delimiter, value = line.removeprefix("export ").partition("=")
            if not delimiter or key.strip() not in {"CF_API_TOKEN", "CF_ACCOUNT_ID"}:
                continue
            value = re.split(r"\s+#", value.strip(), maxsplit=1)[0].rstrip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
                value = value[1:-1]
            values[key.strip()] = value
    account = os.environ.get("CF_ACCOUNT_ID", values.get("CF_ACCOUNT_ID", "")).strip()
    token = os.environ.get("CF_API_TOKEN", values.get("CF_API_TOKEN", "")).strip()
    if not account or not token:
        raise BenchmarkError("NOT_EXECUTED — set CF_ACCOUNT_ID and CF_API_TOKEN.")
    if not re.fullmatch(r"[a-fA-F0-9]{32}", account) or not re.fullmatch(r"[A-Za-z0-9_.~+/-]+", token):
        raise BenchmarkError("Invalid Cloudflare credential format.")
    return account, token


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def object_or_empty(value):
    return value if isinstance(value, dict) else {}


def first_object(value):
    return object_or_empty(value[0]) if isinstance(value, list) and value else {}


def count(value):
    return value if type(value) is int and 0 <= value <= 2**53 - 1 else None


def valid_text(value):
    return value if isinstance(value, str) and value.strip() else None


def parse_reply(raw, status):
    result = object_or_empty(raw.get("result", raw))
    errors = raw.get("errors") or result.get("errors")
    code = count(first_object(errors).get("code"))
    if status in (401, 403):
        return {"outcome": "ACCESS_DENIED", "provider_code": code}
    if status in (402, 429) or code == 3036:
        return {"outcome": "QUOTA_COST_OR_RATE_LIMIT", "provider_code": code}
    if (not 200 <= status < 300 or not raw or errors or raw.get("error") or result.get("error")
            or raw.get("success") is False or result.get("success") is False):
        return {"outcome": "API_ERROR", "provider_code": code}

    choice = first_object(result.get("choices"))
    native = valid_text(result.get("response"))
    answer = native or valid_text(object_or_empty(choice.get("message")).get("content"))
    top_reason = result.get("finish_reason", raw.get("finish_reason"))
    reason = (top_reason or choice.get("finish_reason")) if native else (choice.get("finish_reason") or top_reason)
    reason = (reason if reason in FINISH_REASONS else "unknown") if isinstance(reason, str) else None
    usage = object_or_empty(result.get("usage")) or object_or_empty(raw.get("usage"))
    prompt_tokens = count(usage.get("prompt_tokens"))
    completion_tokens = count(usage.get("completion_tokens"))
    total_tokens = count(usage.get("total_tokens"))
    if total_tokens is None and prompt_tokens is not None and completion_tokens is not None:
        total_tokens = prompt_tokens + completion_tokens
    return {
        "outcome": "API_ERROR" if reason == "error" else "EMPTY" if not answer else "PARTIAL" if reason == "length" else "OK",
        "answer": None if reason == "error" else answer,
        "finish_reason": reason,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
    }


def infer(account, token, model, payload, timeout, opener):
    """Make one HTTPS request and discard native exceptions and raw errors."""
    started = time.monotonic()
    status = None
    request = Request(
        f"https://api.cloudflare.com/client/v4/accounts/{account}/ai/run/{model}",
        data=dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    try:
        with deadline(timeout):
            try:
                response = opener.open(request, timeout=timeout)
            except HTTPError as error:
                response = error
            with response:
                status = response.code
                try:
                    raw = object_or_empty(json.loads(response.read(2 * 1024 * 1024)))
                except (ValueError, UnicodeError):
                    raw = {}
            result = parse_reply(raw, status)
    except (socket.timeout, TimeoutError):
        result = {"outcome": "TIMEOUT"}
    except URLError as error:
        result = {"outcome": "TIMEOUT" if isinstance(error.reason, TimeoutError) else "NETWORK_ERROR"}
    except (OSError, HTTPException):
        result = {"outcome": "NETWORK_ERROR"}
    if result.get("answer"):
        result["answer"] = result["answer"].replace(token, "[REDACTED]").replace(account, "[REDACTED]")
    return {**result, "http_status": status, "latency_ms": round((time.monotonic() - started) * 1000)}


def load_experiment():
    manifest = read_manifest()
    names = {"P2.txt", "P3.txt", "next-holdout.json", "experiment.json"}
    if set(manifest) != names:
        raise BenchmarkError("The experiment manifest is incomplete.")
    contents = {name: (ROOT / name).read_bytes() for name in names}
    if any(sha(content) != manifest[name] for name, content in contents.items()):
        raise BenchmarkError("A frozen input changed. Use the original package.")
    spec = json.loads(contents["experiment.json"])
    if (spec["parameters"] != PARAMETERS or spec["model"] != MODEL or
            spec["timeout_s"] != TIMEOUT or spec["max_attempts"] != BUDGET):
        raise BenchmarkError("Unexpected model, settings, timeout or budget.")
    prompts = {arm: contents[f"{arm}.txt"].decode("utf-8").removesuffix("\n") for arm in ("P2", "P3")}
    if any(sha(text.encode("utf-8")) != spec[f"{arm.lower()}_sha256"] for arm, text in prompts.items()):
        raise BenchmarkError("A prompt does not match the frozen system text.")
    holdout = contents["next-holdout.json"]
    deck = json.loads(holdout)
    cases = deck["cases"]
    if (sha(holdout) != spec["holdout_sha256"] or deck["p3_sha256"] != spec["p3_sha256"] or
            [row["id"] for row in cases] != [f"N{i:02}" for i in range(1, 13)]):
        raise BenchmarkError("Unexpected Holdout set.")
    fingerprint = sha(dumps([sha(Path(__file__).read_bytes()), manifest]).encode())
    return prompts, cases, fingerprint


def trial_plan(cases):
    jobs = []
    for index, item in enumerate(cases):
        # Alternate order on successive pairs to balance order effects.
        order = ("P2", "P3") if index % 2 == 0 else ("P3", "P2")
        for arm in order:
            jobs.append((f"{item['id']}-{arm}", item, arm))
    if len(jobs) != BUDGET:
        raise BenchmarkError("Expected exactly 24 planned calls.")
    return jobs


def payload_for(item, system_prompt):
    return {
        **PARAMETERS,
        "messages": [
            {"role": "system", "content": system_prompt}, *item["history"],
            {"role": "user", "content": item["question"]},
        ],
    }


@contextmanager
def writer_lock():
    with os.fdopen(os.open(ROOT / LOCK_NAME, os.O_RDWR | os.O_CREAT, 0o600), "rb") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise BenchmarkError("The benchmark is already running in this folder.") from None
        yield


def initialize(db, fingerprint):
    db.execute("PRAGMA synchronous=FULL")
    db.executescript("""
        CREATE TABLE IF NOT EXISTS experiment (fingerprint TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS attempts (
            id TEXT PRIMARY KEY,
            case_id TEXT NOT NULL,
            arm TEXT NOT NULL CHECK (arm IN ('P2', 'P3')),
            attempted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            outcome TEXT NOT NULL,
            result TEXT,
            UNIQUE (case_id, arm)
        );
        CREATE TRIGGER IF NOT EXISTS enforce_budget
        BEFORE INSERT ON attempts WHEN (SELECT count(*) FROM attempts) >= 24
        BEGIN
            SELECT RAISE(ABORT, '24-call cap reached');
        END;
    """)
    previous = db.execute("SELECT fingerprint FROM experiment").fetchone()
    if previous and previous[0] != fingerprint:
        raise BenchmarkError("Benchmark code or inputs changed since this run began.")
    if not previous:
        with db:
            db.execute("INSERT INTO experiment VALUES (?)", (fingerprint,))


def run(*, request_once=infer, opener=None):
    prompts, cases, fingerprint = load_experiment()
    jobs = trial_plan(cases)
    with writer_lock():
        # This unique name isolates the earlier results.sqlite3. Reject symlinks.
        db_path = ROOT / DB_NAME
        fd = os.open(db_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        os.close(fd)
        with closing(sqlite3.connect(db_path)) as db:
            initialize(db, fingerprint)
            attempted = {row[0] for row in db.execute("SELECT id FROM attempts")}
            if not attempted.issubset({job[0] for job in jobs}):
                raise BenchmarkError("The results DB is not for this trial plan.")
            with db:
                db.execute("UPDATE attempts SET outcome='INTERRUPTED' WHERE outcome='IN_FLIGHT'")
            remaining = [job for job in jobs if job[0] not in attempted]
            if not remaining:
                print("All 24 trials were already attempted.")
                return 0
            account, token = read_credentials()
            if opener is None:
                opener = build_opener(NoRedirect())
            for trial_id, item, arm in remaining:
                body = payload_for(item, prompts[arm])
                # Commit before dispatch so an unknown outcome is never retried.
                with db:
                    db.execute(
                        "INSERT INTO attempts(id, case_id, arm, outcome) VALUES (?, ?, ?, 'IN_FLIGHT')",
                        (trial_id, item["id"], arm),
                    )
                result = request_once(account, token, MODEL, body, TIMEOUT, opener)
                with db:
                    db.execute("UPDATE attempts SET outcome=?, result=? WHERE id=?",
                               (result["outcome"], dumps(result), trial_id))
                attempted.add(trial_id)
                print(f"{len(attempted)}/{BUDGET} {trial_id} {result['outcome']}", flush=True)
                if result["outcome"] not in CONTINUE:
                    print("Stopped. Check the cause before running again.", file=sys.stderr)
                    return 1
    return 0


TELEMETRY = ("answer", "latency_ms", "prompt_tokens", "completion_tokens", "total_tokens",
             "finish_reason", "http_status", "provider_code")


def results():
    path = ROOT / DB_NAME
    if not path.exists():
        return []
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as db:
        db.row_factory = sqlite3.Row
        rows = []
        for record in db.execute("SELECT * FROM attempts ORDER BY rowid"):
            row = dict(record)
            details = row.pop("result")
            rows.append({**dict.fromkeys(TELEMETRY), **row, **(json.loads(details) if details else {})})
        return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("plan", "run", "status", "export"))
    command = parser.parse_args().command
    if command == "run":
        return run()
    if command == "plan":
        _, cases, _ = load_experiment()
        print(json.dumps({
            "model": MODEL, "parameters": PARAMETERS,
            "planned_attempts": BUDGET, "timeout_s": TIMEOUT, "database": DB_NAME,
            "order": [job[0] for job in trial_plan(cases)],
        }, indent=2))
        return 0
    rows = results()
    if command == "status":
        counts = {}
        for row in rows:
            key = row["outcome"]
            counts[key] = counts.get(key, 0) + 1
        print(json.dumps({"attempted": len(rows), "remaining": BUDGET - len(rows), "outcomes": counts}, indent=2))
    elif command == "export":
        for row in rows:
            print(dumps(row))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit("Stopped. Keep the database and use run to resume without repeating attempts.")
    except BenchmarkError as error:
        sys.exit(str(error))
    except (sqlite3.Error, OSError, UnicodeError, KeyError, ValueError, TypeError):
        sys.exit("Benchmark stopped because the local files, state or response could not be read safely.")
