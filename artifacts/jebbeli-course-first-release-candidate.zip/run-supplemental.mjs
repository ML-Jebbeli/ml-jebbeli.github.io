import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [repo, destination] = process.argv.slice(2);
const { planCourseReply, generalPartOfMixedAnswer } = await import(
  pathToFileURL(resolve(repo, "src/official-course-answers.js"))
);
globalThis.fetch = () => assert.fail("Tests must not contact a real endpoint");

const cases = [
  { id: "S09", message: "شهریه دوره چنده معنی Dropout چیست", expected: "mixed",
    required: "معنی Dropout چیست" },
  { id: "S13", generated: "کلاس حضوری است و درخت تصمیم با کاهش ناخالصی تقسیم می‌کند.",
    forbidden: "کلاس حضوری", required: "درخت تصمیم با کاهش ناخالصی تقسیم می‌کند" },
  { id: "S14", generated: "برنامه از نیمه پاییز آغاز می‌شود.\nمشتق نرخ تغییر را نشان می‌دهد.",
    forbidden: "نیمه پاییز", required: "مشتق نرخ تغییر را نشان می‌دهد" },
  { id: "X01", message: "شهریه چنده یه داستان کوتاه درباره ربات بنویس", expected: "mixed",
    required: "یه داستان کوتاه درباره ربات بنویس" },
  { id: "X02", generated: "کلاس حضوری است؛Dropout در آموزش برخی فعال‌سازی‌ها را تصادفی صفر می‌کند.",
    forbidden: "کلاس حضوری", required: "Dropout در آموزش برخی فعال‌سازی‌ها را تصادفی صفر می‌کند" },
  { id: "X03", generated: "درخت تصمیم با کاهش ناخالصی تقسیم می‌کند اما کلاس حتماً حضوری است.",
    forbidden: "کلاس حتماً حضوری است", required: "درخت تصمیم با کاهش ناخالصی تقسیم می‌کند" },
  { id: "X04", message: "تفاوت list و tuple چیه و یک مثال بزن", expected: "general",
    required: "تفاوت list و tuple چیه و یک مثال بزن" },
  { id: "X05", message: "پس تا کی فرصت دارم؟", history: [
    { role: "user", content: "مهلت ثبت‌نام دوره مشخصه؟" },
    { role: "assistant", content: "تا فردا." },
  ], expected: "course_unknown", requiredAnswer: "مهلت ثبت‌نام قطعی دوره هنوز اعلام نشده", forbidden: "فردا" },
  { id: "X06", message: "شهریه چقد درمیاد فاصله کسینوسی رو توضیح بده", expected: "mixed",
    required: "فاصله کسینوسی رو توضیح بده" },
  { id: "X07", generated: "نوبت بعدی پس از تعطیلات کلید می‌خورد.\nدرخت تصمیم نمونه‌ها را بر اساس ویژگی‌ها جدا می‌کند.",
    forbidden: "پس از تعطیلات", required: "درخت تصمیم نمونه‌ها را بر اساس ویژگی‌ها جدا می‌کند" },
  { id: "X08", generated: "کلاس حضوری است و هر خروجی را بر مجموع نمایی‌ها تقسیم می‌کند.",
    forbidden: "کلاس حضوری", required: "هر خروجی را بر مجموع نمایی‌ها تقسیم می‌کند" },
];
const rows = cases.map((item) => {
  if (item.message) {
    const result = planCourseReply({ message: item.message, history: item.history ?? [] });
    const success = result.route === item.expected &&
      (!item.required || result.message?.includes(item.required)) &&
      (!item.requiredAnswer || (result.answer?.includes(item.requiredAnswer) &&
        result.answer.includes("https://t.me/Iustech_support"))) && !result.answer?.includes(item.forbidden ?? "\0");
    return { ...item, result, status: success ? "PASS" : "FAIL" };
  }
  const result = generalPartOfMixedAnswer(item.generated);
  return { ...item, result, status: result.includes(item.required) && !result.includes(item.forbidden) ? "PASS" : "FAIL" };
});
writeFileSync(destination, JSON.stringify(rows, null, 2) + "\n");
for (const row of rows) console.log(row.id, row.status);
console.log(`${rows.filter((row) => row.status === "PASS").length}/${rows.length} passed.`);
