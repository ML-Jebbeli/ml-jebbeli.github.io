import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [repo, output = "smoke-mock-results.jsonl"] = process.argv.slice(2);
const source = (name) => pathToFileURL(resolve(repo, "src", name)).href;
const { default: worker } = await import(source("preview.js"));
const { nextUtcMidnight } = await import(source("daily-quota.js"));
const { readRecentHistory } = await import(source("conversation.js"));
const { planCourseReply } = await import(source("official-course-answers.js"));
const { cases } = JSON.parse(readFileSync(new URL("./handoff/08_PRODUCTION_SMOKE_TESTS.json", import.meta.url)));
assert.equal(cases.length, 24);
globalThis.fetch = () => assert.fail("Smoke mock must not contact a real endpoint");

const origin = "https://ml-jebbeli.github.io";
const support = "https://t.me/Iustech_support";
const timing = /زمان شروع.*اعلام نشده/u, tuition = /شهریه.*اعلام نشده/u, format = /شیوهٔ برگزاری.*اعلام نشده/u;
const certificate = /گواهی.*اعلام نشده/u, registration = /نمی‌تواند ثبت‌نام/u;
const known = /از مبانی یادگیری ماشین شروع می‌شود/u;
const expected = {
  K01:[known], K02:[/آشنایی مقدماتی با Python توصیه می‌شود/u], K03:[/ریاضی پیشرفته شرط شروع نیست/u],
  K04:[/PyTorch/u,/پروژهٔ عملی/u], K05:[/دورهٔ گذشته.*۲۵ جلسه/u,/تعداد جلسات دورهٔ جدید.*اعلام نشده/u],
  K06:[/سید امیرحسین حسینی جبلی/u],
  U01:[tuition], U02:[tuition], U03:[format], U04:[timing], U05:[timing],
  U06:[certificate], U07:[registration], U08:[/ضبط جلسات.*اعلام نشده/u],
  M01:[tuition,/Dropout در آموزش.*تصادفی/u], M02:[format,/ساختار list تغییرپذیر.*ساختار tuple تغییرناپذیر/u],
  M03:[certificate,/dim=1.*ستون.*هر سطر/u], M04:[known,/PyTorch کتابخانهٔ متن‌باز/u],
  F01:[certificate], F02:[/شرایط قسط.*اعلام نشده/u],
  G01:[/Sigmoid.*Softmax.*مجموع یک/u], G02:[/سلام/u],
  A01:[tuition,timing], A02:[format,registration],
};
const generated = {
  M01:"شهریه چهار میلیون تومان است و Dropout در آموزش بخشی از فعال‌سازی‌ها را تصادفی صفر می‌کند.",
  M02:"کلاس فقط به شکل آنلاین خواهد بود و ساختار list تغییرپذیر است ولی ساختار tuple تغییرناپذیر است.",
  M03:"دوره گواهی بین‌المللی تضمینی می‌دهد؛ PyTorch با `x.sum(dim=1)` روی بُعد ستون جمع می‌زند و برای هر سطر یک مقدار می‌دهد.",
  M04:"نوبت بعدی پس از تعطیلات کلید می‌خورد و PyTorch کتابخانهٔ متن‌باز برای محاسبهٔ تنسوری و یادگیری عمیق است.",
  G01:"Sigmoid هر امتیاز را مستقل بین صفر و یک می‌برد. Softmax همهٔ امتیازها را به مقادیر با مجموع یک تبدیل می‌کند.",
  G02:"سلام! چه کمکی از دستم برمی‌آید؟",
};
const inputChecks = {
  M01:/^معنی Dropout چیست$/u, M02:/^فرق list و tuple چیه$/u,
  M03:/^x\.sum\(dim=1\) چی میده$/u, M04:/^بگو PyTorch دقیقاً چیه$/u,
};
const forbidden = /چهار میلیون|[۵5] میلیون|۱۰ آذر|اول آذر|سه‌شنبه|به شکل آنلاین خواهد بود|گواهی بین‌المللی تضمینی|نوبت بعدی پس از تعطیلات|ثبت‌نام شما تأیید شد/u;

async function ask(message, history, responseText) {
  const calls = [];
  let reservations = 0;
  const limits = { limit: async () => ({ success: true }) };
  const response = await worker.fetch(new Request("https://worker.invalid", {
    method: "POST",
    headers: { Origin: origin, "Content-Type": "application/json", "CF-Connecting-IP": "192.0.2.12" },
    body: JSON.stringify({ message, history }),
  }), {
    CHAT_CLIENT_LIMIT: limits, CHAT_ROUTE_LIMIT: limits,
    DAILY_AI_QUOTA: { getByName: () => ({ reserve: async () => {
      reservations++;
      return { admitted: true, expiresAt: nextUtcMidnight(Date.now()) };
    } }) },
    AI: { run: async (model, options) => {
      calls.push({ model, options });
      return { response: responseText };
    } },
  });
  return {
    status: response.status, cors: response.headers.get("Access-Control-Allow-Origin") === origin,
    answer: (await response.json()).answer ?? "", reservations, calls,
    route: planCourseReply({ message, history: readRecentHistory(history) }).route,
  };
}

const rows = [];
for (const item of cases) {
  const { id, category, question } = item;
  const [previous, current] = question.includes("←") ? question.split("←").map((text) => text.trim()) : [null, question];
  const responseText = generated[id] ?? "شهریه پنج میلیون است و دوره ۱۰ آذر شروع می‌شود.";
  const prior = previous ? await ask(previous, [], responseText) : null;
  const history = prior ? [{ role: "user", content: previous }, { role: "assistant", content: prior.answer }] : [];
  const actual = await ask(current, history, responseText);
  const route = category === "unknown" || category === "followup" || category === "adversarial" || id === "K05"
    ? "course_unknown" : category === "known" ? "course_known" : category;
  const numCalls = route === "general" || route === "mixed" ? 1 : 0;
  const questions = actual.calls.map(({options}) => options.messages.at(-1).content);
  const problems = [];
  if (actual.status !== 200 || !actual.cors || (prior && (prior.status !== 200 || !prior.cors))) problems.push("response-contract");
  if (actual.route !== route) problems.push("route");
  if (actual.calls.length !== numCalls || actual.reservations !== numCalls || (prior && prior.calls.length !== 0)) problems.push("model-or-quota-count");
  if (!expected[id].every((pattern) => pattern.test(actual.answer))) problems.push("answer-concept");
  if (actual.answer.split(support).length !== (item.mandatory_support ? 2 : 1)) problems.push("support");
  if (forbidden.test(actual.answer)) problems.push("unverified-claim");
  if ((inputChecks[id] && !inputChecks[id].test(questions[0] ?? "")) || (category === "general" && questions[0] !== current)) {
    problems.push("question-understanding");
  }
  if (actual.calls.some(({model,options}) => model !== "@cf/zai-org/glm-4.7-flash" ||
    options.temperature !== 0.1 || options.max_completion_tokens !== 700 ||
    options.chat_template_kwargs.enable_thinking !== false || Object.hasOwn(options, "top_p") ||
    Object.hasOwn(options, "top_k"))) problems.push("model-options");
  rows.push({ id, category, question, route: actual.route, mock_http_requests: prior ? 2 : 1,
    model_calls: actual.calls.length + (prior?.calls.length ?? 0), prior_answer: prior?.answer ?? null,
    model_question: questions[0] ?? null, answer: actual.answer, status: problems.length ? "FAIL" : "PASS", problems });
}
writeFileSync(output, rows.map((row) => JSON.stringify(row)).join("\n") + "\n");
const total = (key) => rows.reduce((sum,row) => sum+row[key], 0);
console.log(`${rows.filter((row) => row.status === "PASS").length}/${rows.length} passed, ${total("mock_http_requests")} local HTTP requests, ${total("model_calls")} mock AI calls.`);
for (const row of rows.filter(({ status }) => status === "FAIL")) console.log(row.id,row.problems,row.model_question,row.answer);
if (rows.some(({status}) => status === "FAIL")) process.exitCode = 1;
