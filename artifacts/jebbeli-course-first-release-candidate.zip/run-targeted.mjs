import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [repo = "/workspace/jebbeli-ai-worker-course-first", file = "targeted-results.jsonl"] = process.argv.slice(2);
const source = (name) => pathToFileURL(resolve(repo, "src", name)).href;
const { default: worker } = await import(source("preview.js"));
const { nextUtcMidnight } = await import(source("daily-quota.js"));
const { readRecentHistory } = await import(source("conversation.js"));
const { planCourseReply } = await import(source("official-course-answers.js"));
const { cases } = JSON.parse(readFileSync(new URL("./course-first-regression-12.json", import.meta.url)));
assert.equal(cases.length, 12);
assert.equal(new Set(cases.map(({ id }) => id)).size, 12);

const mock = {
  R01: "اولین جلسه هفته بعد است و ۱۷ روز باقی مانده.",
  R02: "اول آذر شروع می‌شود و جلسه دوم ۸ آذر است.",
  R03: "بله، فردا شروع می‌شود.",
  R04: "قبل از یلدا قطعاً تمام می‌شود.",
  R05: "ساختار list تغییرپذیر است و ساختار tuple تغییرناپذیر است.",
  R06: "مدل مستقیم روی دادهٔ آموزش یاد می‌گیرد و train accuracy می‌تواند بالاتر باشد. اختلاف بزرگ با validation می‌تواند نشانهٔ بیش‌برازش یا تفاوت داده‌ها باشد.",
  R07: 'مثال دیکشنری\n```python\nexample = {"name": "Sara"}\n```',
  R08: "softmax امتیازها را به مقادیر نامنفی با مجموع یک تبدیل می‌کند.",
};
const tuition = /شهریه.*اعلام نشده/u;
const timing = /زمان شروع.*اعلام نشده/u;
const format = /شیوهٔ برگزاری.*اعلام نشده/u;
const direct = {
  R01: timing, R02: timing, R03: timing, R04: /مهلت ثبت‌نام.*اعلام نشده/u,
  R05: tuition, R06: format, R07: /آشنایی مقدماتی با Python توصیه می‌شود/u, R08: /سید امیرحسین حسینی جبلی/u,
  R09: tuition, R10: /گواهی.*اعلام نشده/u, R11: timing, R12: format,
};
const scientific = {
  R05: ["list تغییرپذیر", "tuple تغییرناپذیر"],
  R06: ["train accuracy می‌تواند بالاتر باشد", "اختلاف بزرگ با validation می‌تواند نشانهٔ بیش‌برازش یا تفاوت داده‌ها باشد"],
  R07: ['example = {"name": "Sara"}'],
  R08: ["مقادیر نامنفی با مجموع یک"],
  R09: ["overfitting زمانی رخ می‌دهد", "و روی داده جدید ضعیف عمل کند"],
  R10: ["Dropout", "در آموزش بخشی از فعال‌سازی‌ها را تصادفی صفر می‌کند"],
  R11: ["MAE میانگین قدر مطلق خطاست", "ولی MSE میانگین مربع خطا را محاسبه می‌کند"],
  R12: ["set مجموعهٔ اعضای یکتا است", "dict نگاشت کلید به مقدار است"],
};
const forbidden = {
  R01: /هفته بعد است|۱۷ روز/u, R02: /اول آذر|۸ آذر/u, R03: /فردا/u, R04: /قبل از یلدا|بعد از یلدا/u,
  R05: /۵ میلیون/u, R06: /کلاس حتماً آنلاین است/u, R07: /پایتون پیشرفته الزامی/u, R08: /نام مدرس ساختگی/u,
  R09: /[۴4] میلیون/u, R10: /گواهی بین‌المللی تضمینی/u, R11: /۱۰ آذر/u, R12: /کلاس حتماً حضوری است/u,
};
const stems = {
  R05: /^فرق list با tuple/u, R06: /^چرا train accuracy/u, R07: /^یه مثال کوتاه از dictionary/u, R08: /^softmax چیه/u,
  R09: /^overfitting یعنی چی/u, R10: /^dropout چیه/u, R11: /^تفاوت MAE و MSE/u, R12: /^تفاوت set و dict/u,
};
const support = "https://t.me/Iustech_support";
const origin = "https://ml-jebbeli.github.io";
globalThis.fetch = () => assert.fail("Tests must not contact a real endpoint");

async function ask(item) {
  const { message, history = [] } = item;
  const calls = [];
  let reservations = 0;
  const limiter = { limit: async () => ({ success: true }) };
  const request = new Request("https://worker.invalid/", {
    method: "POST", headers: { Origin: origin, "Content-Type": "application/json", "CF-Connecting-IP": "192.0.2.12" },
    body: JSON.stringify({ message, history }),
  });
  const response = await worker.fetch(request, {
    AI: { run: async (model, options) => {
      calls.push({ model, options });
      return { response: item.mock_glm_response ?? mock[item.id] ?? item.mock };
    } },
    DAILY_AI_QUOTA: { getByName: () => ({ reserve: async () => {
      reservations++;
      return { admitted: true, expiresAt: nextUtcMidnight(Date.now()) };
    } }) },
    CHAT_CLIENT_LIMIT: limiter, CHAT_ROUTE_LIMIT: limiter,
  });
  const modelQuestion = calls[0]?.options.messages.at(-1).content ?? null;
  const checkOptions = calls.every(({ model, options }) =>
    model === "@cf/zai-org/glm-4.7-flash" && options.temperature === 0.1 &&
    options.max_completion_tokens === 700 && options.chat_template_kwargs.enable_thinking === false &&
    !Object.hasOwn(options, "top_p") && !Object.hasOwn(options, "top_k")
  );
  return {
    route: planCourseReply({ message, history: readRecentHistory(history) }).route,
    model_calls: calls.length, reservations, model_question: modelQuestion,
    result: await response.json(), http_status: response.status,
    valid_cors: response.headers.get("Access-Control-Allow-Origin") === origin, model_options_unchanged: checkOptions,
  };
}

const rows = [];
for (const item of cases) {
  const { id, category, message } = item;
  const shown = await ask(item);
  const answer = shown.result.answer ?? "";
  const problems = [];
  if (shown.route !== item.expected_route) problems.push("route");
  const expectedCount = item.expected_route === "mixed" ? 1 : 0;
  if (shown.model_calls !== expectedCount || shown.reservations !== expectedCount) problems.push("model-or-quota-count");
  if (shown.http_status !== 200 || !shown.valid_cors || !shown.model_options_unchanged) problems.push("response-contract");
  if (!direct[id].test(answer)) problems.push("official-concept");
  if (answer.split(support).length !== (item.must_include_support ? 2 : 1)) problems.push("support");
  if (forbidden[id].test(answer) || item.forbidden_claims.some((claim) => answer.includes(claim))) problems.push("forbidden-claim");
  if (item.must_answer_non_course_part && !scientific[id].every((value) => answer.includes(value))) problems.push("missing-science");
  if (stems[id] && !stems[id].test(shown.model_question ?? "")) problems.push("mixed-input-scope");
  rows.push({ id, category, message, mock_glm_response: item.mock_glm_response ?? mock[id],
    ...shown, answer, status: problems.length ? "FAIL" : "PASS", problems });
}
writeFileSync(file, rows.map((row) => JSON.stringify(row)).join("\n") + "\n");
console.log(`${rows.filter((row) => row.status === "PASS").length}/${rows.length} passed; ${rows.reduce((sum, row) => sum + row.model_calls, 0)} mock calls.`);
for (const row of rows) console.log(row.id, row.status, row.route, row.model_calls, row.problems.join(","));
if (rows.some((row) => row.status === "FAIL")) process.exitCode = 1;
