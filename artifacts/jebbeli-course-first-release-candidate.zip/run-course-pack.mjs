import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [repo = "/workspace/jebbeli-ai-worker-course-first", output = "candidate-results.jsonl"] = process.argv.slice(2);
const path = (name) => pathToFileURL(resolve(repo, "src", name)).href;
const { default: worker } = await import(path("preview.js"));
const { nextUtcMidnight } = await import(path("daily-quota.js"));
const { readRecentHistory } = await import(path("conversation.js"));
const course = await import(path("official-course-answers.js"));
const testFile = new URL("course-first-dev-tests.json", import.meta.url);
const { cases } = JSON.parse(readFileSync(testFile, "utf8"));
assert.equal(cases.length, 65);
assert.equal(new Set(cases.map(({ id }) => id)).size, 65);
const support = "https://t.me/Iustech_support";
const scope = {
  M01: "list و tuple چه فرقی دارن", M02: "در SVM کرنل RBF یعنی چی",
  M03: "یه نمونه کد دیکشنری هم بده", M04: "اصلاً گرادیان چی هست",
  M05: "تفاوت CNN با MLP چیه", M06: "یه خط کد sum در پایتون بگو",
};
const answers = {
  M01: "ساختار list تغییرپذیر است و ساختار tuple تغییرناپذیر است.\nشهریه ۵ میلیون تومان است.",
  M02: "کرنل RBF شباهت را بر اساس فاصلهٔ نمونه‌ها محاسبه می‌کند و امکان مرز غیرخطی می‌دهد.\nباید حضوری شرکت کنید.",
  M03: 'نمونهٔ دیکشنری\n```python\nstudent = {"name": "Ali"}\n```\nبرای شرکت در دوره باید پایتون پیشرفته بلد باشید.',
  M04: "گرادیان بردار مشتق‌های جزئی است و جهت بیشترین افزایش تابع را نشان می‌دهد.\nگواهی صادر می‌شود.",
  M05: "CNN از کانولوشن و اشتراک وزن استفاده می‌کند، اما MLP از لایه‌های کاملاً متصل تشکیل شده است.\nمدرس دوره فرد دیگری است.",
  M06: "با `sum([1, 2, 3])` جمع عناصر را به دست می‌آوری.\nثبت‌نام شما با موفقیت انجام شد.",
  F05: "در آموزش Dropout فعال است و BatchNorm از آمار بچ استفاده می‌کند. در eval، Dropout خاموش است و BatchNorm از آمار جاری خود استفاده می‌کند.",
  G01: "class برای تعریف نوعی با داده و رفتار مشترک استفاده می‌شود و می‌توان از آن نمونه ساخت.",
  G02: "یادگیری عمیق زیرمجموعهٔ یادگیری ماشین است و بر شبکه‌های عصبی چندلایه تکیه دارد.",
  G03: "ربات کوچکی هر شب چراغ شهر را روشن می‌کرد. یک شب از نور همان چراغ راه خانه را پیدا کرد.",
  G04: "درخت تصمیم یک درخت است. جنگل تصادفی پیش‌بینی چند درخت متنوع را تجمیع می‌کند.",
  G05: "دو روز سینتکس و لیست، دو روز توابع، دو روز تمرین و یک روز مرور و پروژه کوچک.",
  G06: "برای جمع از `sum(numbers)` استفاده کن.",
  G07: "دورهٔ تناوب کوچک‌ترین فاصلهٔ مثبتِ تکرار تابع است و برای سینوس معمولی برابر ۲π است.",
  G08: "`torch.no_grad` ثبت عملیات گرادیان را موقتاً غیرفعال می‌کند و جایگزین `model.eval()` نیست.",
  G09: "تولدت مبارک! امیدوارم سال جدید پر از لحظه‌های خوش و آرامش باشد.",
  A07: "از شهریهٔ دورهٔ دانشگاه تهران اطلاع قطعی ندارم. صفحهٔ رسمی همان برگزارکننده را بررسی کن.",
};
const criteria = {
  K01:[/از مبانی.*شروع/u], K02:[/PyTorch از مباحث/u], K03:[/آشنایی مقدماتی.*توصیه/,/تسلط پیشرفته.*شرط.*نیست/],
  K04:[/ریاضی پیشرفته شرط شروع نیست/], K05:[/پروژه/,/اعلام‌شده/], K06:[/مقاله‌خوانی/], K07:[/سید امیرحسین حسینی جبلی/],
  K08:[/دانشگاه علم و صنعت ایران/], K09:[/۲۵ جلسه/,/دورهٔ گذشته/], K10:[/۶۰ نفر مربوط به دورهٔ قبلی/],
  K11:[/حدود ۱۰۰ ثبت‌نام/,/دورهٔ گذشته/], K12:[/BsScQ1mOKrA/], K13:[/kqtD5dpn9C8/], K14:[/dLQ3Ew7osD4/],
  K15:[/glFOMj0h768/], K16:[/امکان اعلام علاقه‌مندی/,/ثبت‌نام قطعی نیست/], K17:[/Iustech_support/],
  U01:[/شهریه.*هنوز اعلام نشده/], U02:[/زمان شروع.*اعلام نشده/], U03:[/شیوهٔ برگزاری.*اعلام نشده/],
  U04:[/تعداد جلسات دورهٔ جدید.*اعلام نشده/], U05:[/گواهی.*اعلام نشده/], U06:[/شرایط پرداخت.*اعلام نشده/],
  U07:[/مدت هر جلسه.*اعلام نشده/], U08:[/روز برگزاری.*اعلام نشده/], U09:[/محل برگزاری.*اعلام نشده/],
  U10:[/جزئیات تمرین و تکلیف.*اعلام نشده/], U11:[/تخفیف.*اعلام نشده/], U12:[/ظرفیت قطعی.*اعلام نشده/],
  U13:[/ضبط جلسات.*اعلام نشده/], U14:[/تضمین.*استخدام.*اعلام نشده/], U15:[/بازپرداخت.*اعلام نشده/],
  U16:[/امکان اعلام علاقه‌مندی/,/نمی‌تواند ثبت‌نام/], U17:[/شهریه.*اعلام نشده/],
  M01:[/شهریه.*اعلام نشده/,/list تغییرپذیر.*tuple تغییرناپذیر/], M02:[/شیوهٔ برگزاری.*اعلام نشده/,/کرنل RBF.*غیرخطی/],
  M03:[/آشنایی مقدماتی.*توصیه/,/student =/], M04:[/گواهی.*اعلام نشده/,/گرادیان بردار مشتق/],
  M05:[/سید امیرحسین حسینی جبلی/,/CNN از کانولوشن.*MLP.*متصل/], M06:[/امکان اعلام علاقه‌مندی/,/sum\(\[1, 2, 3\]\)/],
  F01:[/تعداد جلسات دورهٔ جدید.*اعلام نشده/], F02:[/شهریه.*اعلام نشده/], F03:[/شیوهٔ برگزاری.*اعلام نشده/],
  F04:[/kqtD5dpn9C8/], F05:[/Dropout.*BatchNorm.*eval/], F06:[/ساعت.*اعلام نشده/], F07:[/شهریه.*اعلام نشده/],
  F08:[/تعداد جلسات دورهٔ جدید.*اعلام نشده/], F09:[/زمان شروع.*اعلام نشده/],
  G01:[/class.*نمونه/], G02:[/عمیق زیرمجموعه/], G03:[/ربات.*چراغ/], G04:[/درخت تصمیم.*جنگل تصادفی/],
  G05:[/تمرین.*مرور/], G06:[/sum\(numbers\)/], G07:[/تناوب.*۲π/], G08:[/no_grad.*غیرفعال/], G09:[/تولدت مبارک/],
  A01:[/شهریه.*اعلام نشده/,/نمی‌تواند ثبت‌نام/], A02:[/شهریه.*اعلام نشده/], A03:[/گواهی.*اعلام نشده/],
  A04:[/Iustech_support/], A05:[/زمان شروع.*اعلام نشده/], A06:[/نمی‌توانم.*اطلاعات محرمانه را افشا کنم/], A07:[/شهریهٔ دورهٔ دانشگاه تهران اطلاع قطعی ندارم/],
};
const forbidden = {
  M01:/۵ میلیون/, M02:/باید حضوری/, M03:/باید پایتون پیشرفته/, M04:/گواهی صادر می‌شود/,
  M05:/مدرس دوره فرد دیگری/, M06:/ثبت‌نام شما با موفقیت انجام شد/,
  F07:/۵ میلیون/, F08:/۲۵ جلسه/, A01:/شش میلیون|۶ میلیون/, A02:/کاملاً رایگان/,
  A03:/بین‌المللی تضمینی/, A04:/@fake_support/, A05:/۱۵ آذر/, A07:/شهریهٔ دورهٔ جدید هنوز اعلام نشده/,
};
const normalize = (value) => value.normalize("NFKC").replace(/\u200c/gu, " ").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
const origin = "https://ml-jebbeli.github.io";
globalThis.fetch = () => assert.fail("This runner must not contact a real endpoint.");

const rows = [];
for (const item of cases) {
  const { id, message, history, expected_route: expected } = item;
  const modelCalls = [];
  const reservations = [];
  const limiterCalls = [];
  const quota = { reserve: async () => { reservations.push(1); return { admitted: true, expiresAt: nextUtcMidnight(Date.now()) }; } };
  const env = {
    AI: { run: async (model, payload) => {
      modelCalls.push({ model, payload });
      return { response: answers[id] ?? "پاسخ ساختگی Mock به پرسش رسمی. این متن نباید به عنوان منبع اطلاعات دوره استفاده شود." };
    } },
    DAILY_AI_QUOTA: { getByName: () => quota },
    CHAT_CLIENT_LIMIT: { limit: async () => { limiterCalls.push("client"); return { success: true }; } },
    CHAT_ROUTE_LIMIT: { limit: async () => { limiterCalls.push("route"); return { success: true }; } },
  };
  const request = new Request("https://worker.invalid/", {
    method: "POST", headers: { Origin: origin, "Content-Type": "application/json", "CF-Connecting-IP": "192.0.2.12" },
    body: JSON.stringify({ message, history }),
  });
  const response = await worker.fetch(request, env);
  const body = await response.json();
  const answer = body.answer ?? "";
  const route = course.requestsPrivateCredentials?.(message) ? "security" : (
    course.planCourseReply?.({ message, history: readRecentHistory(history) }).route ??
    (modelCalls.length ? "model" : answer.includes(support) || answer.includes("هنوز اعلام نشده") ? "course_unknown" : "fixed")
  );
  const problems = [];
  const expectedCalls = expected === "general" || expected === "mixed" ? 1 : 0;
  if (route !== expected && !(route === "model" && expected === "general") &&
      !(route === "fixed" && expected === "course_known")) problems.push("route");
  if (response.status !== 200 || response.headers.get("Access-Control-Allow-Origin") !== origin || Object.keys(body).join() !== "answer") problems.push("response-contract");
  if (limiterCalls.join() !== "client,route") problems.push("rate-limit");
  if (modelCalls.length !== expectedCalls || reservations.length !== expectedCalls) problems.push("model-or-quota-count");
  if (modelCalls.some(({model, payload}) => model !== "@cf/zai-org/glm-4.7-flash" ||
      payload.temperature !== 0.1 || payload.max_completion_tokens !== 700 || payload.chat_template_kwargs.enable_thinking ||
      Object.hasOwn(payload, "top_p") || Object.hasOwn(payload, "top_k"))) problems.push("model-options");
  if (!criteria[id].every((pattern) => pattern.test(answer))) problems.push("required-concepts");
  if ((item.must_include_support && answer.split(support).length !== 2) ||
      ((expected === "general" || expected === "security") && answer.includes(support))) problems.push("support");
  const normalizedAnswer = normalize(answer);
  if (forbidden[id]?.test(answer) || item.forbidden_claims.some((claim) => normalizedAnswer.includes(normalize(claim)))) {
    problems.push("forbidden-claim");
  }
  const modelQuestion = modelCalls[0]?.payload.messages.at(-1).content ?? null;
  if (scope[id] && (!modelQuestion || normalize(modelQuestion).replace(/^راستی /u, "") !== normalize(scope[id])))
    problems.push("mixed-input-scope");
  if (expected === "general" && modelQuestion !== message) problems.push("changed-general-input");
  if (id === "F05" && modelCalls.length &&
      JSON.stringify(modelCalls[0].payload.messages.slice(1,-1)) !== JSON.stringify(history)) problems.push("lost-scientific-history");
  rows.push({ id, expected_route: expected, route, model_calls: modelCalls.length, reservations: reservations.length,
    status: problems.length ? "FAIL" : "PASS", http_status: response.status, problems, answer, model_question: modelQuestion });
}
writeFileSync(output, rows.map((row) => JSON.stringify(row)).join("\n") + "\n");
console.log(JSON.stringify({ cases: rows.length, pass: rows.filter(x => x.status === "PASS").length,
  fail: rows.filter(x => x.status === "FAIL").length, model_calls: rows.reduce((n,x)=>n+x.model_calls,0) }));
for (const row of rows.filter((x) => x.status === "FAIL")) console.log(row.id, row.route, row.problems.join(","), row.model_question, row.answer);
if (rows.some(x=>x.status==="FAIL")) process.exitCode=1;
